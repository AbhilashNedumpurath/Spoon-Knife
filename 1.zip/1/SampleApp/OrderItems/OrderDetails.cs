﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleApp.OrderItems
{
    //public class OrderItem
    //{
    //    public string Name
    //    {
    //        get;
    //        set;
    //    }


    //}
}
