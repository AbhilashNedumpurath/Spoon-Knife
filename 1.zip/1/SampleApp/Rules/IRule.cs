﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SampleApp.Rules
{
    public interface IRule
    {
        public void Execute();
    }
}
