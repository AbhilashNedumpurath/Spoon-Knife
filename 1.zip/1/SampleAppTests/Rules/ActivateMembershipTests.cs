﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SampleApp.Rules;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleApp.Rules.Tests
{
    [TestClass()]
    public class ActivateMembershipTests
    {
       
    }
}