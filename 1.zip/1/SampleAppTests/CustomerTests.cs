﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SampleApp;
using System;
using System.Collections.Generic;
using System.Text;

namespace SampleApp.Tests
{
    [TestClass()]
    public class CustomerTests
    {
       
    }
}